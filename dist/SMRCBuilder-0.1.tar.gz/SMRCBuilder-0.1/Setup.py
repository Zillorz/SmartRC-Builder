from setuptools import setup, find_packages

setup(
    name='SMRCBuilder',
    version="0.1",
    author="NoKodaAddictions",
    author_email="airomech404@gmail.com",
    packages=find_packages()
)