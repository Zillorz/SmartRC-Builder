class ArgError(Exception):
    pass

class SocketError(Exception):
    pass

class ServerHostingError(Exception):
    pass

class ClientConnectionError(Exception):
    pass

class MessageError(Exception):
    pass